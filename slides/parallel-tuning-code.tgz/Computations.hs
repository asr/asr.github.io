{-# LANGUAGE UnicodeSyntax #-}

module Computations (ack, fib) where

import Numeric.Natural ( Natural )

fib ∷ Natural → Natural
fib 0 = 0
fib 1 = 1
fib n = fib (n - 1) + fib (n - 2)

ack ∷ Natural → Natural → Natural
ack 0 y = y + 1
ack x 0 = ack (x - 1) 1
ack x y = ack (x - 1) (ack x (y - 1))
