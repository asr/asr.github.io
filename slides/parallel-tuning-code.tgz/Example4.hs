-- Example 4: A Correct Parallelisation

-- Tested with GHC 8.2.1 and parallel 3.2.1.1.

import Computations     ( ack, fib )
import Control.Parallel ( par, pseq )
import Numeric.Natural  ( Natural )

pFibAck :: Natural -> Natural -> Natural -> Natural
pFibAck n x y = par f $ pseq a (f + a)
  where
  f = fib n
  a = ack x y

main :: IO ()
-- main = print $ pFibAck 36 3 10
main = print $ pFibAck 39 3 11
