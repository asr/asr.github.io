-- Example 1: Sequential Implementation

-- Tested with GHC 8.2.1.

import Computations    ( ack, fib )
import Numeric.Natural ( Natural )

pFibAck :: Natural -> Natural -> Natural -> Natural
pFibAck n x y = f + a
  where
  f = fib n
  a = ack x y

main :: IO ()
-- main = print $ pFibAck 36 3 10
main = print $ pFibAck 39 3 11
