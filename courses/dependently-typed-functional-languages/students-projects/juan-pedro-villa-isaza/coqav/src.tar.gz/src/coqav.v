(* ************************************************************************ *)
(* Coq au vin - The Coq proof assistant and the Curry-Howard correspondence *)
(*                                                                          *)
(* Juan Pedro Villa-Isaza (jvillais@eafit.edu.co)                           *)
(* ************************************************************************ *)

(* (Tested with Coq 8.2pl2.) *)

Section Coqav.

Section Propositional_logic.

  (* Example *)

  Section imp_trans.

  Hypothesis P : Prop.
  Hypothesis Q : Prop.

  Hypotheses R S : Prop.

  Theorem imp_trans1 : (P -> Q) -> (Q -> R) -> P -> R.
  Proof.
    intro H1.
    intros H2 p.
    apply H2.
    apply H1.
    assumption.
  Qed.

  Print imp_trans1.

  Theorem imp_trans2 : (P -> Q) -> (Q -> R) -> P -> R.
  Proof.
    auto.
  Qed.

  Print imp_trans2.

  End imp_trans.

  (* Implication (function space) *)

  Section Implication.

  (* A |- B       *)
  (* ====== (->I) *)
  (* A -> B       *)

  (* A -> B  A       *)
  (* ========= (->E) *)
  (* B               *)

  End Implication.

  (* Conjunction (product) *)

  Section Conjunction.

  (* A  B         *)
  (* ====== (/\I) *)
  (* A /\ B       *)

  Print and.

  (* A /\ B        A /\ B        *)
  (* ====== (/\E1) ====== (/\E2) *)
  (* A             B             *)

  Print proj1.
  Print proj2.

  End Conjunction.

  (* Disjunction (disjoint sum) *)

  Section Disjunction.

  (* A             B             *)
  (* ====== (\/I1) ====== (\/I2) *)
  (* A \/ B        A \/ B        *)

  Print or.

  (* A \/ B  A |- C  B |- C       *)
  (* ====================== (\/E) *)
  (* C                            *)

  Print or_ind.

  End Disjunction.

  (* Absurdity (empty type) *)

  Section Absurdity.

  Print False.

  Print False_ind.

  End Absurdity.

  (* True *)

  Section True.

  Print True.

  End True.

  (* Negation *)

  Section Negation.

  Print not.

  End Negation.

  (* Bi-implication *)

  Section Biimplication.

  Print iff.

  End Biimplication.

  (* Example 1 *)

  Section Example1.

    Theorem example1 : forall A : Prop, A -> ~ ~ A.
    Proof.
      unfold not.
      intros A a H.
      apply H.
      assumption.
    Qed.

  Print example1.

  End Example1.

  (* Example 2 *)

  Section Example2.

    Lemma example2_1 : forall A B C : Prop, A /\ (B \/ C) -> A /\ B \/ A /\ C.
    Proof.
      intros A B C H1.
      elim H1.
      intros a H2.
      elim H2.
        intro b.
        constructor 1.
        constructor.
          assumption.

          assumption.

        auto.
    Qed.

    Print example2_1.

    Lemma example2_2 : forall A B C : Prop, A /\ B \/ A /\ C -> A /\ (B \/ C).
    Proof.
      intros A B C H1.
      elim H1.
        intro H2.
        elim H2.
        intros a b.
        constructor.
          assumption.

          constructor 1.
          assumption.

        intro H2.
        elim H2.
        auto.
    Qed.

    Print example2_2.

    Theorem example2 : forall A B C : Prop, A /\ (B \/ C) <-> A /\ B \/ A /\ C.
    Proof.
      intros A B C.
      unfold iff.
      constructor.
        exact (example2_1 A B C).

        apply example2_2.
    Qed.

    Print example2.

  End Example2.

  Section Exercises.

    (* Are the following formulas intuitionistically valid? *)
    (* Are the following types inhabited?                   *)

    Theorem exercise1 : forall P Q R : Prop, ((((P -> Q) -> R) -> (P -> R) -> R) -> Q) -> Q.
    Proof.
      intros P Q R H1.
      apply H1.
      intros H2 H3.
      apply H2.
      intro p.
      apply H1.
      intros _ _.
      apply H3.
      assumption.
    Qed.

    Theorem exercise2 : forall P : Prop, (P -> ~ P) -> (~ P -> P) -> False.
    Proof.
      unfold not.
      intros P H1 H2.
      apply H1.
        apply H2.
        intro p.
        apply H1.
          assumption.

          assumption.

        apply H2.
        intro p.
        apply H1.
          assumption.

          assumption.
    Qed.

    Hypotheses P Q R S : Prop.

    (* id_P *)

    Lemma lemma1 : P -> P.
    Proof.
      intro p.
      assumption.
    Qed.

    (* id_PP *)

    Lemma lemma2 : (P -> P) -> (P -> P).
    Proof.
      intro H.
      assumption.
    Qed.

    (* imp_trans *)

    Lemma lemma3 : (P -> Q) -> (Q -> R) -> P -> R.
    Proof.
      intros H1 H2 p.
      apply H2.
      apply H1.
      assumption.
    Qed.

    (* imp_perm *)

    Lemma lemma4 : (P -> Q -> R) -> (Q -> P -> R).
    Proof.
      intros H q p.
      apply H.
        assumption.

        assumption.
    Qed.

    (* ignore_Q *)

    Lemma lemma5 : (P -> R) -> P -> Q -> R.
    Proof.
      intros H p _.
      apply H.
      assumption.
    Qed.

    (* delta_imp *)

    Lemma lemma6 : (P -> P -> Q) -> P -> Q.
    Proof.
      intros H p.
      apply H.
        assumption.

        assumption.
    Qed.

    (* delta_impR *)

    Lemma lemma7 : (P -> Q) -> (P -> P -> Q).
    Proof.
      intros H _.
      assumption.
    Qed.

    (* diamond *)

    Lemma lemma8 : (P -> Q) -> (P -> R) -> (Q -> R -> S) -> P -> S.
    Proof.
      intros H1 H2 H3 p.
      apply H3.
        apply H1.
        assumption.

        apply H2.
        assumption.
    Qed.

    (* weak_peirce *)

    Lemma lemma9 : ((((P -> Q) -> P) -> P) -> Q) -> Q.
    Proof.
      intro H1; apply H1.
      intro H2; apply H2.
      intro p.
      apply H1.
      intros _.
      assumption.
    Qed.

  End Exercises.

End Propositional_logic.

Section Predicate_logic.

  Print all.

  Print ex.

  Section Examples.

  Hypothesis A C : Prop.
  Hypothesis B : A -> Prop.

  Theorem exampleA : ~ ex B <-> (forall x : A, ~ B x).
  Proof.
    unfold not.
    unfold iff.
    constructor.
      intros H1 x Bx.
      apply H1.
      exists x.
      assumption.

      intros H1 H2.
      elim H2.
      intros x Bx.
      apply H1 with x.
      assumption.
  Qed.

  Theorem exampleB : forall x : A, B x -> ex B.
  Proof.
    apply ex_intro.
  Qed.

  Hypothesis a : A.

  Theorem exampleC : ex (A:=A) (fun _ => C) <-> C.
  Proof.
    unfold iff.
    constructor.
      intro H1.
      elim H1.
      intros _ c.
      assumption.

      intro c.
      constructor.
        assumption.

        assumption.
  Qed.

  End Examples.

End Predicate_logic.

Section Proof_irrelevance.

  Lemma lemma7_1 : forall P Q : Prop, (P -> Q) -> (P -> P -> Q).
  Proof.
    intros P Q H _.
    assumption.
  Qed.

  Lemma lemma7_2 : forall P Q : Prop, (P -> Q) -> (P -> P -> Q).
  Proof.
    intros P Q H p1 p2.
    apply H.
    assumption.
  Qed.

  Require Import ProofIrrelevance.

  Print proof_irrelevance.

  Lemma lemma7_12 : lemma7_1 = lemma7_2.
  Proof.
    apply proof_irrelevance.
  Qed.

  Print lemma7_12.

End Proof_irrelevance.

End Coqav.
