------------------------------------------------------------------------------
-- Coq au vin - The Coq proof assistant and the Curry-Howard correspondence
--
-- Juan Pedro Villa-Isaza (jvillais@eafit.edu.co)
------------------------------------------------------------------------------

-- (Tested with Agda 2.2.10.)

module Coqav where

------------------------------------------------------------------------------
-- Propositional logic

infix  6 ~_
infixr 5 _∧_
infixr 4 _∨_
infixr 2 _⇔_

-- Example

impTrans₁ : {P Q R : Set} → (P → Q) → (Q → R) → P → R
impTrans₁ H₁ H₂ p = H₂ (H₁ p)

impTrans₂ : {P Q R : Set} → (P → Q) → (Q → R) → P → R
impTrans₂ = λ H₁ H₂ p → H₂ (H₁ p)

-- Implication (function space)

-- A ⊢ B
-- ===== (→I)
-- A → B

-- A → B  A
-- ======== (→E)
-- B

-- Conjunction (product)

-- A  B
-- ===== (∧I)
-- A ∧ B

data _∧_ (A B : Set) : Set where
  conj : A → B → A ∧ B

-- A ∧ B       A ∧ B
-- ===== (∧E₁) ===== (∧E₂)
-- A           B

proj₁ : {A B : Set} → A ∧ B → A
proj₁ (conj a b) = a

proj₂ : {A B : Set} → A ∧ B → B
proj₂ (conj a b) = b

-- Disjunction (disjoint sum)

-- A           B
-- ===== (∨I₁) ===== (∨I₂)
-- A ∨ B       A ∨ B

data _∨_ (A B : Set) : Set where
  orIntroL : A → A ∨ B
  orIntroR : B → A ∨ B

-- A ∨ B  A ⊢ C  A ⊢ C
-- =================== (∨E)
-- C

orInd : {A B C : Set} → (A → C) → (B → C) → A ∨ B → C
orInd f g (orIntroL a) = f a
orInd f g (orIntroR b) = g b

-- Absurdity (empty type)

data False : Set where

FalseInd : {A : Set} → False → A
FalseInd ()

-- True

data True : Set where
  I : True

-- Negation

~_ : Set → Set
~ A = A → False

-- Bi-implication

_⇔_ : Set → Set → Set
A ⇔ B = (A → B) ∧ (B → A)

-- Example 1

example₁ : {A : Set} → A → ~ ~ A
example₁ a a→False = a→False a

-- Example 2

example₂₁ : {A B C : Set} → A ∧ (B ∨ C) → A ∧ B ∨ A ∧ C
example₂₁ (conj a (orIntroL b)) = orIntroL (conj a b)
example₂₁ (conj a (orIntroR c)) = orIntroR (conj a c)

example₂₂ : {A B C : Set} → A ∧ B ∨ A ∧ C → A ∧ (B ∨ C)
example₂₂ (orIntroL (conj a b)) = conj a (orIntroL b)
example₂₂ (orIntroR (conj a c)) = conj a (orIntroR c)

example₂ : {A B C : Set} → A ∧ (B ∨ C) ⇔ A ∧ B ∨ A ∧ C
example₂ = conj example₂₁ example₂₂

------------------------------------------------------------------------------
-- Exercises

-- Are the following formulas intuitionistically valid?
-- Are the following types inhabited?

exercise₁ : {P Q R : Set} → ((((P → Q) → R) → (P → R) → R) → Q) → Q
exercise₁ H₁ = H₁ (λ H₂ H₃ → H₂ (λ p → H₁ (λ _ _ → H₃ p)))

exercise₂ : {P : Set} → (P → ~ P) → (~ P → P) → False
exercise₂ H₁ H₂ = H₁ (H₂ (λ p → H₁ p p)) (H₂ (λ p → H₁ p p))

-- id_P

lemma₁ : {P : Set} → P → P
lemma₁ p = p

-- id_PP

lemma₂ : {P : Set} → (P → P) → (P → P)
lemma₂ H = H

-- imp_trans

lemma₃ : {P Q R : Set} → (P → Q) → (Q → R) → P → R
lemma₃ H₁ H₂ p = H₂ (H₁ p)

-- imp_perm

lemma₄ : {P Q R : Set} → (P → Q → R) → (Q → P → R)
lemma₄ H₁ H₂ p = H₁ p H₂

-- ignore_Q

lemma₅ : {P Q R : Set} → (P → R) → P → Q → R
lemma₅ H p _ = H p

-- delta_imp

lemma₆ : {P Q : Set} → (P → P → Q) → P → Q
lemma₆ H p = H p p

-- delta_impR

lemma₇ :{P Q : Set} → (P → Q) → (P → P → Q)
lemma₇ H _ = H

-- diamond

lemma₈ : {P Q R S : Set} → (P → Q) → (P → R) → (Q → R → S) → P → S
lemma₈ H₁ H₂ H₃ p = H₃ (H₁ p) (H₂ p)

-- weak_peirce

lemma₉ : {P Q : Set} → ((((P → Q) → P) → P) → Q) → Q
lemma₉ H₁ = H₁ (λ H₂ → H₂ (λ p → H₁ (λ _ → p)))
