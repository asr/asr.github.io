module Util where
import Database.HDBC
import Data.List
import Database.HDBC.PostgreSQL (connectPostgreSQL)

getRows :: [[SqlValue]] -> IO ()
getRows  r =
  do
    let stringRows = map convrow r

    mapM_ putStrLn stringRows

convrow :: [SqlValue] -> String
convrow = unwords . intersperse "|" . map fromSql