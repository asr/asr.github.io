------------------------------------------------------------------------------
-- Using FFI’s pragmas in Agda
--
-- Andrés Eugenio Castaño Cardenas (acastan7@eafit.edu.co)
------------------------------------------------------------------------------

-- (Tested with Agda 2.2.10. and the standard library 0.5)

module DB_project_p where

open import IO.Primitive as IO
open import Data.String as String renaming (_++_ to _¡_)
open import Data.Char as Char using (Char;_==_)
open import Foreign.Haskell
open import Function
open import Category.Functor
open import Category.Monad
open import Category.Monad.Indexed
open import Data.Nat

Monadio : RawMonad IO
Monadio = record { return = IO.return
                 ; _>>=_  = IO._>>=_
                 }

open RawMonad Monadio hiding (_>>=_)

data dbList (a : Set) : Set where
    []   : dbList a
    _∷_ : a → dbList a → dbList a

{-# COMPILED_DATA dbList [] [] (:) #-}

postulate Integer : Set
{-# BUILTIN INTEGER Integer #-}
{-# COMPILED_TYPE Integer Integer #-}

primitive
  primIntegerAbs   : Integer → ℕ
  primNatToInteger : ℕ → Integer

postulate
  SqlValue : Set
  SqlColDesc : Set

{-# COMPILED_TYPE SqlColDesc Database.HDBC.SqlColDesc #-}
{-# COMPILED_TYPE SqlValue Database.HDBC.SqlValue #-}

ServerName = String
DbName     = String
UserName   = String
Query      = String
Value      = SqlValue
Row        = dbList Value


{-# IMPORT Database.HDBC #-}
{-# IMPORT Database.HDBC.PostgreSQL #-}
{-# IMPORT Util #-}

postulate
  Connection    : Set
  getRows       : dbList Row → IO Unit
  dbconnect     : String → IO Connection
  dbquery       : Connection → Query → dbList Value → IO (dbList Row)
  dbotrans      : Connection → Query → dbList Value → IO Integer
  dbcommit      : Connection → IO Unit

{-# COMPILED_TYPE Connection Database.HDBC.PostgreSQL.Connection #-}
{-# COMPILED dbconnect Database.HDBC.PostgreSQL.connectPostgreSQL #-}
{-# COMPILED dbquery Database.HDBC.quickQuery' #-}
{-# COMPILED dbotrans Database.HDBC.run #-}
{-# COMPILED dbcommit Database.HDBC.commit #-}
{-# COMPILED getRows Util.getRows #-}

s∞connection : ServerName → DbName → UserName → String
s∞connection s d u = "host=" ¡ s ¡ " dbname=" ¡ d ¡ " user=" ¡ u

query : ServerName → DbName → UserName → String → IO Unit
query sn db un query = dbconnect (s∞connection sn db un) >>= λ conn → 
  dbquery conn query [] >>= λ rows → getRows rows

otherT : ServerName → DbName → UserName → String → IO Unit
otherT sn db un query = dbconnect (s∞connection sn db un) >>= λ conn →
  dbotrans conn query [] >> dbcommit conn

main = query "localhost" "test_ah" "postgres" "SELECT * FROM test WHERE id < 2"