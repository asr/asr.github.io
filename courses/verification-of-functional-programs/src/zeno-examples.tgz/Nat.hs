{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE UnicodeSyntax #-}

-- Tested with zeno 0.2.0.1 and GHC 7.0.4.

-- From the Example.hs file in the zeno package.

-- Using the tool
-- $ zeno -i ~/src/zeno-0.2.0.1/ Nat.hs

module Nat where

import Prelude ()
import Zeno
------------------------------------------------------------------------------
class Num a where
  (+), (-), (*), (^) ∷ a -> a -> a

-- Data type
data Nat = Zero | Succ Nat

-- Num instance
instance Num Nat where
  Zero   + y = y
  Succ x + y = Succ (x + y)

  x      - Zero   = x
  Zero   - y      = Zero
  Succ x - Succ y = x - y

  Zero   * y = Zero
  Succ x * y = y + (x * y)

  x ^ Zero   = Succ Zero
  x ^ Succ y = x * (x ^ y)

------------------------------------------------------------------------------
-- Properties

prop_add_right_ident (x ∷ Nat)
  = prove (x + Zero :=: x)

prop_add_commu (x ∷ Nat) y
  = prove (x + y :=: y + x)
