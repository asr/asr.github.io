{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE UnicodeSyntax #-}

-- Tested with zeno 0.2.0.1 and GHC 7.0.4.

-- From Drosspoulou's slides.

-- Using the tool
-- $ zeno -i ~/src/zeno-0.2.0.1/ InsertSort.hs

module InsertSort where

import Prelude ()
import Zeno
------------------------------------------------------------------------------

data Nat = Zero | Succ Nat

(&&) ∷ Bool → Bool → Bool
True && True = True
_    && _    = False

(<=) ∷ Nat → Nat → Bool
Zero   <= _      = True
Succ x <= Zero   = False
Succ x <= Succ y = x <= y

srtd ∷ [Nat] → Bool
srtd []           = True
srtd [x]          = True
srtd (x : y : zs) = (x <= y) && srtd (y : zs)

ins ∷ Nat → [Nat] → [Nat]
ins n []     = [n]
ins n (x : xs)
  | n <= x    = n : x : xs
  | otherwise = x : ins n xs

ordr ∷ [Nat] → [Nat]
ordr []       = []
ordr (x : xs) = ins x (ordr xs)

------------------------------------------------------------------------------
-- Property

prop_ordr_correct (is ∷ [Nat])  = prove (srtd (ordr is) :=: True)
