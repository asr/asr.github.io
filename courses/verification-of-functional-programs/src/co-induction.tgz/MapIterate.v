(* Tested with Coq 8.9.1 *)

(* The map-iterate property *)

(* Adapted from: Eduardo Giménez and Pierre Castéran. A Tutorial on
[Co-]Inductive Types in Coq. May 1998 -- August 17, 2007. *)

Require Import Unicode.Utf8.

Set Implicit Arguments.

CoInductive Stream (A : Type) : Type :=
  cons : A → Stream A → Stream A.

Notation "x ∷ xs" := (cons x xs) (at level 60, right associativity).

Definition head (A : Type)(xs : Stream A) : A :=
  match xs with x' ∷ _ => x' end.

Definition tail (A : Type)(xs : Stream A) : Stream A :=
  match xs with _ ∷ xs' => xs' end.

CoFixpoint iterate (A : Type)(f : A → A)(a : A) : Stream A :=
  a ∷ iterate f (f a).

CoFixpoint map (A B : Type)(f : A → B)(xs : Stream A) : Stream B:=
  match xs with x' ∷ xs' => f x' ∷ map f xs' end.

(* Equality on streams. Relation of bisimilarity. *)
CoInductive EqStream (A : Type) : Stream A → Stream A → Prop :=
  eqS : ∀ xs ys : Stream A,
        head xs = head ys →
        EqStream (tail xs) (tail ys) →
        EqStream xs ys.

Notation "xs ≈ ys" := (EqStream xs ys) (at level 70, no associativity).

(* Co-induction principle for the equality on streams. *)
CoFixpoint
  co_ind (A : Type)
         (R : Stream A → Stream A → Prop)
         (h : ∀ xs ys : Stream A, R xs ys →
              head xs = head ys ∧ R (tail xs) (tail ys))
         (xs ys : Stream A) (r : R xs ys) : xs ≈ ys :=
  eqS xs ys (proj1 (h xs ys r)) (co_ind R h (tail xs) (tail ys)
      (proj2 (h xs ys r))).

(* The map-iterate property *)
Theorem
  map_iterate (A : Type)(f : A → A)(x : A)
              : map f (iterate f x) ≈ iterate f (f x).
Proof.
apply co_ind with
  (R := λ xs ys, ∃ x : A, xs = map f (iterate f x) ∧ ys = iterate f (f x)).
intros xs ys (x', (eqxs, eqys)).
split.
rewrite eqxs; rewrite eqys.
simpl.
reflexivity.
exists (f x').
split.
rewrite eqxs.
simpl.
reflexivity.
rewrite eqys.
reflexivity.
exists x; split; reflexivity.
Qed.
