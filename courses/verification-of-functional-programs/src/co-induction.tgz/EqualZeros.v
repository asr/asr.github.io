(* Tested with Coq 8.9.1. *)

(* The HALO paper. *)
(* Vytiniotis, Dimitrios, Peyton Jones, Simon, Rosén, Dan and Claessen, *)
(* Koen (2013). HALO: Haskell to Logic thorugh Denotational *)
(* Semantics. In: Proceedings of the 40th annual ACM SIGPLAN-SIGACT *)
(* Symposium on Principles of Programming Languages (POPL ’13), *)
(* pp. 431–442. *)

Require Import Unicode.Utf8.

Set Implicit Arguments.

(* Co-inductive natural numbers. *)
CoInductive Conat : Set :=
| zero : Conat
| succ : Conat → Conat.

CoFixpoint inf : Conat := succ inf.

(* Streams (unbounded lists). *)
CoInductive Stream (A : Type) : Type :=
  cons : A → Stream A → Stream A.

Notation "x ∷ xs" := (cons x xs) (at level 60, right associativity).

CoFixpoint zeros : Stream Conat := zero ∷ zeros.
CoFixpoint ones  : Stream Conat := succ zero ∷ ones.

(* Head function on streams. *)
Definition head (A : Type)(xs : Stream A) : A :=
  match xs with x' ∷ _ => x' end.

(* Tail function on streams. *)
Definition tail (A : Type)(xs : Stream A) : Stream A :=
  match xs with _ ∷ xs' => xs' end.

(* Equality on streams. Relation of bisimilarity. *)
CoInductive EqStream (A : Type) : Stream A → Stream A → Prop :=
  eqS : ∀ xs ys : Stream A,
        head xs = head ys →
        EqStream (tail xs) (tail ys) →
        EqStream xs ys.

Notation "xs ≈ ys" := (EqStream xs ys) (at level 70, no associativity).

(* The function from the HALO paper adapted to work on streams instead
of co-inductive lists. *)
CoFixpoint f (n : Conat) : Stream Conat :=
match n with
  | zero    => ones
  | succ n' => zero ∷ f n'
end.

(* Co-induction principle for the equality on streams. *)
CoFixpoint
 co_ind : ∀ A : Type, ∀ R : Stream A → Stream A → Prop,
          (∀ xs ys : Stream A, R xs ys →
            head xs = head ys ∧ R (tail xs) (tail ys)) →
          (∀ xs ys : Stream A, R xs ys → xs ≈ ys).
intros A R h xs ys r.
apply eqS.
apply h.
exact r.
apply (co_ind A R h).
apply h.
exact r.
Qed.

(* Property from the HALO paper. *)
Theorem equalZeros : f inf ≈ zeros.
apply co_ind with
  (R := λ xs ys, xs = f inf ∧ ys = zeros).
intros xs ys h.
split.
destruct h as [h1 h2].
rewrite h1.
rewrite h2.
simpl.
auto.
split.
destruct h as [h1 h2].
rewrite h1.
simpl.
auto.
destruct h as [h1 h2].
rewrite h2.
simpl.
auto.
auto.
Qed.
