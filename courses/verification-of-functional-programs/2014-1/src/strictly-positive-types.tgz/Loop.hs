{-# LANGUAGE UnicodeSyntax #-}

-- Tested with GHC 8.6.5.

-- From Agda source code, test/fail/PureAgda.agda

module Loop where

data D = Lam (D → D)

(∘)  ∷ D → D → D
Lam f ∘ x = f x

δ ∷ D
δ = Lam (\x → x ∘ x)

loop ∷ D
loop = δ ∘ δ

-- We have an infinite unfolding
--
-- loop = δ · δ
--      = lam (\x → x · x) · lam (\x → x · x)
--      = (\x → x · x) (lam (\x → x · x))
--      = lam (\x → x · x) · lam (\x → x · x)
--      = loop
