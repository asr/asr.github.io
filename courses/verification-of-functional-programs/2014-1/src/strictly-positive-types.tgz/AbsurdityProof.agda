{-# OPTIONS --no-positivity-check #-}

-- Tested with Agda 2.6.0.1 and Agda Standard Library 1.1.

-- Using a non-strictly positive type is possible to get a
-- contradiction. From Coq'Art, section 14.1.2.1.

module AbsurdityProof where

open import Data.Empty
open import Data.Nat renaming ( suc to succ )
open import Relation.Binary.PropositionalEquality
open ≡-Reasoning
open import Relation.Nullary

data Bad : Set where
  bad : (Bad → Bad) → Bad

abstract
  depth : Bad → ℕ
  depth (bad f) = succ (depth (f (bad f)))

  depth-eq : {f : Bad → Bad} → depth (bad f) ≡ succ (depth (f (bad f)))
  depth-eq = refl

n≢Sn : {n : ℕ} → ¬ (n ≡ succ n)
n≢Sn ()

thm : depth (bad (λ b → b)) ≡ succ (depth (bad (λ b → b)))
thm =
    begin
      depth (bad (λ b → b))
    ≡⟨ depth-eq ⟩
      succ (depth ((λ b → b) (bad (λ b → b))))
    ≡⟨ refl ⟩
      succ (depth (bad (λ b → b)))
    ∎

absurdity : ⊥
absurdity = n≢Sn thm
