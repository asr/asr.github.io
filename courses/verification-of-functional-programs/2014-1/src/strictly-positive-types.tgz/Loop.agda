{-# OPTIONS --no-positivity-check #-}

-- Tested with Agda 2.6.0.1

-- From Agda source code, test/fail/PureAgda.agda

module Loop where

data D : Set where
  lam : (D → D) → D

_·_ : D → (D → D)
lam f · x = f x

δ : D
δ = lam (λ x → x · x)

loop : D
loop = δ · δ

-- We have an infinite unfolding
--
-- loop = δ · δ
--      = lam (\x → x · x) · lam (\x → x · x)
--      = (\x → x · x) (lam (\x → x · x))
--      = lam (\x → x · x) · lam (\x → x · x)
--      = loop
