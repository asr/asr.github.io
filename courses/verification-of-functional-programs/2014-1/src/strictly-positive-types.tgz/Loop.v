(* Tested with Coq 8.9.1. *)

(* We cannot write down infinite unfolding example. *)

Require Import Unicode.Utf8.

Inductive D : Set :=
| lam : (D → D) → D.

(* Error: Non strictly positive occurrence of "D" in "(D → D) → D". *)
