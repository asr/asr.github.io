module TM (Direction(L,R),
           TM,
           Transition,
           Γ,
           TransitionM,
           Q(..),
           newTM,
           newTMWithInput,
           step,
           stepM,
           run,
           runM,
           move,
           writeSym) where

import Data.List (intersperse)

----- Data Types -----

-- Some states to play with.
data Q = Q0 | Q1 | Q2 | Q3 | Q4 | Q5
     deriving (Eq, Show, Ord)

-- For the sake of simplicity I fixed the alphabet to the available chars.
type Γ = Char

data Tape = Tape {left   :: [Γ],
                  center ::  Γ,
                  right  :: [Γ]}

-- The Turing machine just carries the current state and the tape
data TM a = TM {state :: a, tape :: Tape}

-- The possible directions.
data Direction = L | R
     deriving Show

-- A helpful alias for the transitions.
type Transition q = q -> Γ -> (q, Γ, Direction)

-- A helpful alias for monadic transitions.
type TransitionM m q = q -> Γ -> m (q, Γ, Direction)

----- Show Instances ------
instance Show Tape where
         show (Tape l c r) =
              concat ["...", reverse $ separate l, center', separate r, "...\n"]
              ++ replicate 13 ' ' ++ "^\n"
                  where separate = intersperse '|' . take 5
                        center' = '(':c:")"

instance (Show a) => Show (TM a) where
         show (TM a t) =
              concat ["State: ", show a, "\n", show t]

-- Creates a new tape full of whitespace.
newTape :: Tape
newTape = Tape (repeat ' ') ' ' (repeat ' ')

-- Creates a TM in the given state with an empty tape
newTM :: q -> TM q
newTM q = TM q newTape

-- Creates a new TM with the given input
newTMWithInput :: a -> [Γ] -> TM a
newTMWithInput q i = move R $ TM q $ newTape { right = i ++ repeat ' '}

-- Writes the given symbol in the tape
writeSym :: Γ -> TM t -> TM t
writeSym s (TM q t) = TM q t {center = s}

-- Moves control unit either to the left or the right
move :: Direction -> TM t -> TM t
move L (TM q (Tape (l:ls) s (r:rs))) = TM q (Tape ls l (s:r:rs))
move R (TM q (Tape (l:ls) s (r:rs))) = TM q (Tape (s:l:ls) r rs)
move _ _ = undefined -- The impossible just happened

-- Executes the transition function one step
step :: Transition s -> TM s -> TM s
step f tm@(TM q (Tape _ s _)) =
     let (q', s', d) = f q s
     in (move d . writeSym s' $ tm) {state = q'}

-- Monadic version of step
stepM :: (Monad m) => TransitionM m s -> TM s -> m (TM s)
stepM f tm@(TM q (Tape _ s _)) = do
     (q', s', d) <- f q s
     return $ (move d . writeSym s' $ tm) {state = q'}

-- Creates an infinite list with all the states of the TM
-- Something like a "trace" of the TM.
run :: Transition s -> TM s -> [TM s]
run t mt = iterate (step  t) mt

-- Monadic equivalent of run
runM :: (Monad m) =>
       TransitionM m s
        -> TM s
        -> [m (TM s)]
runM f = iterate (>>= stepM f) . return
