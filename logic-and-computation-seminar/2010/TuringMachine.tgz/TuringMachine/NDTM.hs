module NDTM where

import TM

-- Simple configuration to recognize 0^n1^n strings.

zeroN_OneN :: Transition Q
zeroN_OneN Q0 '0' =  (Q1, 'X', R)
zeroN_OneN Q1 '0' =  (Q1, '0', R)
zeroN_OneN Q2 '0' =  (Q2, '0', L)
zeroN_OneN Q1 '1' =  (Q2, 'Y', L)
zeroN_OneN Q2 'X' =  (Q0, 'X', R)
zeroN_OneN Q0 'Y' =  (Q3, 'Y', R)
zeroN_OneN Q1 'Y' =  (Q1, 'Y', R)
zeroN_OneN Q2 'Y' =  (Q2, 'Y', L)
zeroN_OneN Q3 'Y' =  (Q3, 'Y', R)
zeroN_OneN Q3 ' ' =  (Q4, ' ', R)

take14AndPrint :: (Show a) => [a] -> IO ()
take14AndPrint = mapM_ print . take 14


example1 :: IO ()
example1 = take14AndPrint . run zeroN_OneN $ newTMWithInput Q0 "0011"

example2 :: IO ()
example2 = take14AndPrint . run zeroN_OneN $ newTMWithInput Q0 "1100"

-- So here we have a problem. The undefined transitions throw an ugly error
-- message.
-- We can either change our implementation of TM or we can just
-- use the modified runM to use the simplest fail computation (Maybe)

zeroN_OneNM :: (Monad m) => TransitionM m Q
zeroN_OneNM Q0 '0' = return (Q1, 'X', R)
zeroN_OneNM Q1 '0' = return (Q1, '0', R)
zeroN_OneNM Q2 '0' = return (Q2, '0', L)
zeroN_OneNM Q1 '1' = return (Q2, 'Y', L)
zeroN_OneNM Q2 'X' = return (Q0, 'X', R)
zeroN_OneNM Q0 'Y' = return (Q3, 'Y', R)
zeroN_OneNM Q1 'Y' = return (Q1, 'Y', R)
zeroN_OneNM Q2 'Y' = return (Q2, 'Y', L)
zeroN_OneNM Q3 'Y' = return (Q3, 'Y', R)
zeroN_OneNM Q3 ' ' = return (Q4, ' ', R)
zeroN_OneNM _ _    = fail "Undefined"

zeroN_OneNMaybe :: TransitionM Maybe Q
zeroN_OneNMaybe = zeroN_OneNM

zeroN_OneNList :: TransitionM [] Q
zeroN_OneNList = zeroN_OneNM

example3 = take14AndPrint . runM zeroN_OneNMaybe $ newTMWithInput Q0 "0011"
example6 = take14AndPrint . runM zeroN_OneNMaybe $ newTMWithInput Q0 "1100"

example5 = take14AndPrint . runM zeroN_OneNList $ newTMWithInput Q0 "1100"

-- But. What else can we do?  The monad mechanism is much more powerful. We can
-- implement a non-deterministic TM just by using the non-deterministic monad (AKA
-- list)
-- http://www.cs.odu.edu/~toida/nerzic/390teched/tm/othertms.html
--
--            +--+  a/a R  +--+  _/_ S  +--+
--     ------>|Q0|-------->|Q1|-------->|Q4|
--         +->+--+         +--+         +--+
--         |  | a/a R
--         +--+
--
--

oneOrMore :: TransitionM [] Q 
oneOrMore Q0 'a' = [(Q1, 'a', R), (Q0, 'a', R)]
oneOrMore Q1 x   = [(Q4, x, R)]
oneOrMore _ _    = []

example4 = mapM_ print . take 4  . runM oneOrMore $ newTMWithInput Q0 "aa"

