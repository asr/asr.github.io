module ProbabilisticTM where

import Numeric.Probability.Distribution (uniform, pretty, T)
import TM

instance Eq (TM a) where
         x == y = False

instance (Ord a) => Ord (TM a) where
         compare x y = LT

--oneOrMore :: (Fractional prob) => Q -> Char -> T prob (Q, Char, Direction)
oneOrMore Q0 'a' = uniform [(Q1, 'a', R), (Q0, 'a', R)]
oneOrMore Q1 x   = uniform [(Q4, x, R)]
--oneOrMore _ _    = fail "Undefined"
oneOrMore _ x    = uniform [(Q3, x, R)]


example1 :: [T Double (TM Q)]
example1 = take 4  . runM oneOrMore $ newTMWithInput Q0 "aa"
printExample1 = mapM_ (putStrLn . pretty show) example1