module IOTM where
import TM

-- \t will be our control char.
getInput :: TransitionM IO Q
getInput Q0  _   =  return (Q1, 'C', R)
getInput Q1  _   =  readLn  >>= (\ x -> return (Q2, x, R))
getInput Q2  c   =  return (Q3, c, L)
getInput Q3 '\n' =  return (Q4, ' ', L)
getInput Q3  c   =  return (Q1, c, R)
getInput Q4 'C'  =  return (Q5, ' ', R)
getInput Q4  x   =  return (Q4, x, L)
getInput Q5  _   =  fail "finished"


example1 :: [IO (TM Q)]
example1 = runM getInput $ newTMWithInput Q0 ""


