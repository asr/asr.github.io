{-# LANGUAGE PatternGuards #-}

import Control.Monad
import Data.Bits
import Data.Function
import Control.Arrow
import Data.List (find)

data Expr a = a :+: a
          | a   :*: a
          | a   :/: a
          | a   :<<: a
          | a   :>>: a
          | Var String
          | Const Int
          deriving (Show)

type Env = [(String, Int)]

countVars :: Expr -> Int
countVars (Const v) = 0
countVars (Var s)   = 1
countVars expr =
    let go = on (+) countVars
    in case expr of
      (exprL :+:  exprR) -> go exprL exprR
      (exprL :*:  exprR) -> go exprL exprR
      (exprL :/:  exprR) -> go exprL exprR
      (exprL :<<: exprR) -> go exprL exprR
      (exprL :>>: exprR) -> go exprL exprR

countConstants :: Expr -> Int
countConstants (Const v) = 1
countConstants (Var s)   = 0
countConstants expr =
    let go = on (+) countConstants
    in case expr of
      (exprL :+:  exprR) -> go exprL exprR
      (exprL :*:  exprR) -> go exprL exprR
      (exprL :/:  exprR) -> go exprL exprR
      (exprL :<<: exprR) -> go exprL exprR
      (exprL :>>: exprR) -> go exprL exprR

allConstants :: Expr -> [Int]
allConstants (Const v) = [v]
allConstants (Var s)   = []
allConstants expr =
    let go = on (++) allConstants
    in case expr of
      (exprL :+:  exprR) -> go exprL exprR
      (exprL :*:  exprR) -> go exprL exprR
      (exprL :/:  exprR) -> go exprL exprR
      (exprL :<<: exprR) -> go exprL exprR
      (exprL :>>: exprR) -> go exprL exprR

allVariables :: Expr -> [String]
allVariables (Const _) = []
allVariables (Var s)   = [s]
allVariables expr =
    let go = on (++) allVariables
    in case expr of
      (exprL :+:  exprR) -> go exprL exprR
      (exprL :*:  exprR) -> go exprL exprR
      (exprL :/:  exprR) -> go exprL exprR
      (exprL :<<: exprR) -> go exprL exprR
      (exprL :>>: exprR) -> go exprL exprR

eval :: (Monad m) =>  Env -> Expr -> (m Int)
eval env (exprL :+:  exprR) = (liftM2 (+))    (eval env exprL) (eval env exprR)
eval env (exprL :*:  exprR) = (liftM2 (*))    (eval env exprL) (eval env exprR)
eval env (exprL :/:  exprR) = (liftM2 div)    (eval env exprL) (eval env exprR)
eval env (exprL :<<: exprR) = (liftM2 shiftL) (eval env exprL) (eval env exprR)
eval env (exprL :>>: exprR) = (liftM2 shiftR) (eval env exprL) (eval env exprR)
eval env (Const v) = return v
eval env (Var s) =
    case lookup s env of
      (Just x) -> return x
      Nothing  -> fail $ unwords ["Variable:", show s, "not found"]

log2 :: (Num a, Integral b) => a -> Maybe b
log2 n = fmap snd $ find ((==n) . fst) . map ((2^) &&& id ) $ [2..30]

divAsShift :: Expr -> Expr
divAsShift (exprL :+:  exprR) = (on (:+:)  divAsShift) exprL exprR
divAsShift (exprL :*:  exprR) = (on (:*:)  divAsShift) exprL exprR
divAsShift (exprL :<<: exprR) = (on (:<<:) divAsShift) exprL exprR
divAsShift (exprL :>>: exprR) = (on (:>>:) divAsShift) exprL exprR
divAsShift (exprL :/:  (Const n)) = 
    case log2 n of
      (Just l) -> (divAsShift exprL) :>>: (Const l)
      Nothing  -> (divAsShift exprL) :/:  (Const n)
divAsShift (exprL :/:  exprR) = (on (:/:)  divAsShift) exprL exprR
divAsShift expr = expr

-- tests:
-- divAsShift (Const 8 :/: Const 4)
-- eval [] $ divAsShift (Const 8 :/: Const 4)

mulAsShift (exprL :+:  exprR) = (on (:+:)  mulAsShift) exprL exprR
mulAsShift (exprL :/:  exprR) = (on (:/:)  mulAsShift) exprL exprR
mulAsShift (exprL :<<: exprR) = (on (:<<:) mulAsShift) exprL exprR
mulAsShift (exprL :>>: exprR) = (on (:>>:) mulAsShift) exprL exprR
mulAsShift (exprL :*:  exprR)
           | (Const n) <- exprL, Just l <- log2 n = mulAsShift exprR :<<: Const l
           | (Const n) <- exprR, Just l <- log2 n = mulAsShift exprL :<<: Const l
           | otherwise = (on (:*:)  mulAsShift) exprL exprR
mulAsShift expr = expr

-- eval [] $ mulAsShift (Const 8 :*: Const 4) 
-- eval [] $  (Const 8 :*: Const 4) 
