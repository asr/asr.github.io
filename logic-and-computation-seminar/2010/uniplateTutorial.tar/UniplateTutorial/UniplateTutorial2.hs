{-# LANGUAGE DeriveDataTypeable, PatternGuards #-}
import Data.Generics.Uniplate.Data

import Data.Data
import Data.Typeable
import Control.Monad
import Data.Bits
import Control.Arrow
import Data.List (find)

data Expr = Expr :+: Expr
          | Expr :*: Expr
          | Expr :/: Expr
          | Expr :<<: Expr
          | Expr :>>: Expr
          | Var String
          | Const Int
          deriving (Data, Typeable, Show)

type Env = [(String, Int)]

countVars :: Expr -> Int
countVars expr = length [() | (Var _) <- universe expr]
-- countVars (Var "a" :*: Var "b")

countConsts :: Expr -> Int
countConsts expr = length [() | (Const _) <- universe expr]
-- countConsts (Const 1 :*: Const 2)

allConsts :: Expr -> [Int]
allConsts expr = [c | (Const c) <- universe expr]
-- allConsts (Const 1 :*: Const 2)

allVars :: Expr -> [String]
allVars expr = [s | (Var s) <- universe expr]
-- allVars (Var "a" :*: Var "b")

log2 n = fmap snd $ find ((==n) . fst) . map ((2^) &&& id ) $ [2..30]

divAsShift = transform f
    where f expr@(exprL :/: Const k)
              | (Just l) <- log2 k =  divAsShift exprL :>>: Const l
              | otherwise = expr
          f x = x
-- -- divAsShift (Const 8 :/: Const 4)
-- -- eval [] $ divAsShift (Const 8 :/: Const 4)

mulAsShift = transform f
    where f expr@(exprL :*: exprR)
              | (Const n) <- exprL, Just l <- log2 n = exprR :<<: Const l
              | (Const n) <- exprR, Just l <- log2 n = exprL :<<: Const l
              | otherwise = expr
          f x = x

replaceVars env = transformM f
    where f (Var x)
              | (Just v) <- lookup x env = return (Const v)
              | otherwise = fail $ unwords ["Variable:", show x, "not found"]
          f x = return x

-- replaceVars [("a", 1), ("b", 2)] (Var "a" :*: Var "b")

eval env = liftM (para f) . replaceVars env
       where f (_:+:_)   = sum
             f (_:*:_)   = product
             f (_:/:_)   = foldl1 div
             f (_:<<:_)  = foldl1 shiftL
             f (_:>>:_)  = foldl1 shiftR
             f (Const t) = const t

-- eval [("a", 1), ("b", 2)] ((Var "a" :<<: Var "b") :+: Const 1)
-- eval [] $ mulAsShift (Const 8 :*: Const 4)
-- eval [] $  (Const 8 :*: Const 4)
