{-# LANGUAGE PatternGuards #-}
import Data.Generics.Uniplate

import Data.Data
import Data.Typeable
import Control.Monad
import Data.Bits
import Control.Arrow
import Data.List (find)

data Expr = Expr :+: Expr
          | Expr :*: Expr
          | Expr :/: Expr
          | Expr :<<: Expr
          | Expr :>>: Expr
          | Var String
          | Const Int
          deriving Show

instance Uniplate Expr where
    uniplate (exprL :+:  exprR) = ([exprL, exprR], \[a, b] -> a :+: b)
    uniplate (exprL :*:  exprR) = ([exprL, exprR], \[a, b] -> a :*: b)
    uniplate (exprL :/:  exprR) = ([exprL, exprR], \[a, b] -> a :/: b)
    uniplate (exprL :<<: exprR) = ([exprL, exprR], \[a, b] -> a :<<: b)
    uniplate (exprL :>>: exprR) = ([exprL, exprR], \[a, b] -> a :>>: b)
    uniplate expr = ([], \[] -> expr)

children' :: (Uniplate u) => u -> [u]
children' = fst . uniplate

universe' :: (Uniplate u) => u -> [u]
universe' x = x: concatMap universe' (children x)

countVars expr = length [() | (Var _) <- universe' expr]
-- countVars (Var "a" :*: Var "b")

transform' :: (Uniplate u) => (u -> u) -> u -> u
transform' f x = f $ ctx $ map (transform' f) children
    where (children, ctx) = uniplate x

para' :: (Uniplate u) => (u -> [r] -> r) -> u -> r
para' f x = f x $ map (para' f) $ children' x

replaceVars env = transformM f
    where f (Var x)
              | (Just v) <- lookup x env = return (Const v)
              | otherwise = fail $ unwords ["Variable:", show x, "not found"]
          f x = return x

-- replaceVars [("a", 1), ("b", 2)] (Var "a" :*: Var "b")

eval env = liftM (para' f) . replaceVars env
       where f (_:+:_)   = sum
             f (_:*:_)   = product
             f (_:/:_)   = foldl1 div
             f (_:<<:_)  = foldl1 shiftL
             f (_:>>:_)  = foldl1 shiftR
             f (Const t) = const t

